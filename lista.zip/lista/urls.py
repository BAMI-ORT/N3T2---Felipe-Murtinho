from django.urls import path
from . import views

app_name = 'lista'

urlpatterns = [
    path('', views.jogo_lista, name='jogo_lista'),
    path('jogo/novo/', views.jogo_criar, name='jogo_criar'),
    path('jogo/<int:pk>/', views.jogo_detalhe, name='jogo_detalhe'),
    path('jogo/<int:pk>/editar/', views.jogo_editar, name='jogo_editar'),
    path('jogo/<int:pk>/deletar/', views.jogo_delete, name='jogo_delete'),
]