from django.db import models

class Jogo(models.Model):
    titulo = models.CharField(max_length=100)
    desenvolvedora = models.CharField(max_length=120)
    ano_lancamento = models.IntegerField()
    plataforma = models.CharField(max_length=120)
    def __str__(self):
        return self.titulo
