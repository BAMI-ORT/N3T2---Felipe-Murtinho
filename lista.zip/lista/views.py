from django.shortcuts import render, redirect, get_object_or_404
from .models import Jogo
from .forms import JogoForm

def jogo_lista(request):
    jogos = Jogo.objects.all().order_by('titulo')
    return render(request, 'lista/jogo_lista.html', {'jogos': jogos})

def jogo_criar(request):
    if request.method == "POST":
        form = JogoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista:jogo_lista')
    else:
        form = JogoForm()
    return render(request, 'lista/jogo_form.html', {'form': form})

def jogo_detalhe(request, pk):
    jogo = get_object_or_404(Jogo, pk=pk)
    return render(request, 'lista/jogo_detalhe.html', {'jogo': jogo})

def jogo_editar(request, pk):
    jogo = get_object_or_404(Jogo, pk=pk)
    if request.method == "POST":
        form = JogoForm(request.POST, instance=jogo)
        if form.is_valid():
            form.save()
            return redirect('lista:jogo_detalhe', pk=jogo.pk)
    else:
        form = JogoForm(instance=jogo)
    return render(request, 'lista/jogo_form.html', {'form': form, 'jogo': jogo, 'titulo_pagina': 'Editar Jogo'})

def jogo_delete(request, pk):
    jogo = get_object_or_404(Jogo, pk=pk)
    if request.method == "POST":
        jogo.delete()
        return redirect('lista:jogo_lista')
    return render(request, 'lista/jogo_delete.html', {'jogo': jogo})